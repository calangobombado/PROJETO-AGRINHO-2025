let harvester; // Objeto da nossa colheitadeira
let crops = []; // Array para as plantações
let particles = []; // Partículas para feedback visual
let score = 0;
let machineHealth = 100; // Saúde ou durabilidade da máquina
let harvestEfficiency = 1; // Multiplicador de pontos por colheita
let gameStarted = false; // Controle de estado do jogo

const CROP_SIZE = 30;
const HARVESTER_SIZE = 60;
const NUM_CROPS_INITIAL = 15; // Número inicial de plantações
const REGEN_INTERVAL = 150; // Frames para regenerar plantações (mais rápido)
let frameCounter = 0;
let level = 1; // Nível do jogo
const MAX_HEALTH = 100; // Saúde máxima da máquina

// Cores para o jogo
const COLOR_SKY = [135, 206, 250]; // Azul celeste
const COLOR_FIELD = [120, 180, 70]; // Verde vivo para o campo
const COLOR_HARVESTER_BODY = [255, 180, 0]; // Amarelo vibrante
const COLOR_HARVESTER_CABIN = [80, 80, 80]; // Cinza escuro
const COLOR_HARVESTER_GLASS = [150, 200, 255, 200]; // Vidro da cabine
const COLOR_HARVESTER_TIRES = [30, 30, 30]; // Preto
const COLOR_HARVESTER_CUTTER = [200, 100, 0]; // Laranja enferrujado
const COLOR_HARVESTER_DETAIL = [180, 120, 0]; // Marrom para detalhes
const COLOR_CROP = [70, 160, 70]; // Verde de planta
const COLOR_PARTICLE = [255, 255, 0]; // Amarelo para partículas de colheita

function setup() {
  createCanvas(800, 600);
  harvester = new Harvester(width / 2, height - 70);

  // Gera as plantações iniciais
  for (let i = 0; i < NUM_CROPS_INITIAL; i++) {
    crops.push(new Crop(random(50, width - 50), random(height / 4 + CROP_SIZE, height - 150 - CROP_SIZE)));
  }
}

function draw() {
  background(COLOR_SKY[0], COLOR_SKY[1], COLOR_SKY[2]); // Céu azul claro

  if (!gameStarted) {
    drawStartScreen();
    return;
  }

  // Desenha o "campo"
  fill(COLOR_FIELD[0], COLOR_FIELD[1], COLOR_FIELD[2]);
  noStroke(); // Remove bordas
  rect(0, height / 4, width, height * 3 / 4);

  // Atualiza e desenha a colheitadeira
  harvester.update();
  harvester.display();

  // Desenha e verifica as plantações
  for (let i = crops.length - 1; i >= 0; i--) {
    crops[i].display();

    // Colisão e colheita
    if (harvester.collidesWith(crops[i])) {
      score += 1 * harvestEfficiency;
      machineHealth = max(0, machineHealth - 0.5 * (1 + level * 0.05)); // Desgaste aumenta com o nível

      // Gera partículas na posição da colheita
      for (let p = 0; p < 5; p++) {
        particles.push(new Particle(crops[i].x, crops[i].y));
      }

      crops.splice(i, 1);
    }
  }

  // Atualiza e desenha partículas
  for (let i = particles.length - 1; i >= 0; i--) {
    particles[i].update();
    particles[i].display();
    if (particles[i].isFinished()) {
      particles.splice(i, 1);
    }
  }

  // Regenera plantações periodicamente
  frameCounter++;
  // Aumenta o número máximo de plantações com o nível
  if (frameCounter % REGEN_INTERVAL === 0 && crops.length < NUM_CROPS_INITIAL * (1 + level * 0.2)) {
    crops.push(new Crop(random(50, width - 50), random(height / 4 + CROP_SIZE, height - 150 - CROP_SIZE)));
  }

  // Lógica de avanço de nível
  if (score >= level * 50) { // A cada 50 pontos (ou mais para níveis avançados)
    level++;
    harvester.speed = min(harvester.maxSpeed, harvester.speed + 0.5); // Colheitadeira um pouco mais rápida
    machineHealth = MAX_HEALTH; // Restaura a saúde no novo nível
    // Opcional: Adicionar mais plantações ou um novo tipo de obstáculo aqui
  }

  // Exibe a UI (pontuação, saúde da máquina, eficiência, nível)
  displayUI();

  // Verifica as condições de fim de jogo
  checkGameEnd();
}

function keyPressed() {
  if (!gameStarted) {
    if (keyCode === ENTER) {
      gameStarted = true;
    }
    return;
  }

  if (keyCode === LEFT_ARROW) {
    harvester.setDirection(-1, 0);
  } else if (keyCode === RIGHT_ARROW) {
    harvester.setDirection(1, 0);
  } else if (keyCode === UP_ARROW) {
    harvester.setDirection(0, -1);
  } else if (keyCode === DOWN_ARROW) {
    harvester.setDirection(0, 1);
  }

  if (key === 'W' || key === 'w') {
    harvester.speed = min(harvester.maxSpeed, harvester.speed + 1);
    harvestEfficiency = min(2, harvestEfficiency + 0.1);
  } else if (key === 'S' || key === 's') {
    harvester.speed = max(1, harvester.speed - 1);
    harvestEfficiency = max(0.5, harvestEfficiency - 0.1);
  }
}

function keyReleased() {
  if (gameStarted) {
    if (keyCode === LEFT_ARROW || keyCode === RIGHT_ARROW || keyCode === UP_ARROW || keyCode === DOWN_ARROW) {
      harvester.setDirection(0, 0);
    }
  }
}

// --- Classes do Jogo ---

class Harvester {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.speed = 3;
    this.maxSpeed = 8;
    this.dirX = 0;
    this.dirY = 0;
    this.angle = 0; // Para rotação visual
  }

  update() {
    this.x += this.dirX * this.speed;
    this.y += this.dirY * this.speed;

    this.x = constrain(this.x, HARVESTER_SIZE / 2, width - HARVESTER_SIZE / 2);
    this.y = constrain(this.y, height / 4 + HARVESTER_SIZE / 2, height - HARVESTER_SIZE / 2);

    machineHealth = max(0, machineHealth - (0.01 + (this.speed * 0.005) * (1 + level * 0.02))); // Desgaste aumenta com o nível

    // Atualiza o ângulo para visual de movimento
    if (this.dirX === 1) {
      this.angle = PI / 2; // Virar para a direita
    } else if (this.dirX === -1) {
      this.angle = -PI / 2; // Virar para a esquerda
    } else if (this.dirY === 1) {
      this.angle = PI; // Virar para baixo
    } else if (this.dirY === -1) {
      this.angle = 0; // Virar para cima
    }
  }

  display() {
    push(); // Salva o estado atual da transformação
    translate(this.x, this.y); // Move a origem para o centro da colheitadeira
    rotate(this.angle); // Rotaciona a colheitadeira
    rectMode(CENTER); // Desenha retângulos a partir do centro

    // Corpo principal (traseiro)
    fill(COLOR_HARVESTER_BODY[0], COLOR_HARVESTER_BODY[1], COLOR_HARVESTER_BODY[2]);
    rect(0, HARVESTER_SIZE * 0.1, HARVESTER_SIZE * 0.9, HARVESTER_SIZE * 0.7);

    // Corpo frontal (motor/mecanismos)
    fill(COLOR_HARVESTER_BODY[0] * 0.8, COLOR_HARVESTER_BODY[1] * 0.8, COLOR_HARVESTER_BODY[2] * 0.8); // Um tom mais escuro
    rect(0, -HARVESTER_SIZE * 0.2, HARVESTER_SIZE * 0.7, HARVESTER_SIZE * 0.5);

    // Cabine
    fill(COLOR_HARVESTER_CABIN[0], COLOR_HARVESTER_CABIN[1], COLOR_HARVESTER_CABIN[2]);
    rect(HARVESTER_SIZE * 0.25, -HARVESTER_SIZE * 0.55, HARVESTER_SIZE * 0.4, HARVESTER_SIZE * 0.45); // Cabine deslocada para um lado

    // Vidro da cabine
    fill(COLOR_HARVESTER_GLASS[0], COLOR_HARVESTER_GLASS[1], COLOR_HARVESTER_GLASS[2], COLOR_HARVESTER_GLASS[3]);
    rect(HARVESTER_SIZE * 0.25, -HARVESTER_SIZE * 0.58, HARVESTER_SIZE * 0.3, HARVESTER_SIZE * 0.35);

    // Pneu traseiro maior
    fill(COLOR_HARVESTER_TIRES[0], COLOR_HARVESTER_TIRES[1], COLOR_HARVESTER_TIRES[2]);
    ellipse(-HARVESTER_SIZE * 0.35, HARVESTER_SIZE * 0.35, HARVESTER_SIZE * 0.4, HARVESTER_SIZE * 0.4); // Pneu traseiro esquerdo
    ellipse(HARVESTER_SIZE * 0.35, HARVESTER_SIZE * 0.35, HARVESTER_SIZE * 0.4, HARVESTER_SIZE * 0.4); // Pneu traseiro direito

    // Pneu dianteiro menor
    ellipse(-HARVESTER_SIZE * 0.2, -HARVESTER_SIZE * 0.1, HARVESTER_SIZE * 0.25, HARVESTER_SIZE * 0.25); // Pneu dianteiro esquerdo
    ellipse(HARVESTER_SIZE * 0.2, -HARVESTER_SIZE * 0.1, HARVESTER_SIZE * 0.25, HARVESTER_SIZE * 0.25); // Pneu dianteiro direito

    // Plataforma de corte (cabeçalho)
    fill(COLOR_HARVESTER_CUTTER[0], COLOR_HARVESTER_CUTTER[1], COLOR_HARVESTER_CUTTER[2]);
    rect(0, -HARVESTER_SIZE * 0.8, HARVESTER_SIZE * 1.5, HARVESTER_SIZE * 0.3); // Mais largo e na frente

    // Detalhes na plataforma de corte (lâminas ou rolos)
    fill(COLOR_HARVESTER_DETAIL[0], COLOR_HARVESTER_DETAIL[1], COLOR_HARVESTER_DETAIL[2]);
    for (let i = -0.6; i <= 0.6; i += 0.3) {
      rect(HARVESTER_SIZE * i, -HARVESTER_SIZE * 0.8, HARVESTER_SIZE * 0.08, HARVESTER_SIZE * 0.3);
    }

    // Tubo de descarga (simples)
    fill(COLOR_HARVESTER_DETAIL[0], COLOR_HARVESTER_DETAIL[1], COLOR_HARVESTER_DETAIL[2]);
    rect(HARVESTER_SIZE * 0.4, -HARVESTER_SIZE * 0.3, HARVESTER_SIZE * 0.15, HARVESTER_SIZE * 0.5); // Base do tubo
    rect(HARVESTER_SIZE * 0.4, -HARVESTER_SIZE * 0.6, HARVESTER_SIZE * 0.15, HARVESTER_SIZE * 0.3); // Parte superior do tubo
    // Para dar uma sensação de curvatura
    arc(HARVESTER_SIZE * 0.4, -HARVESTER_SIZE * 0.6, HARVESTER_SIZE * 0.3, HARVESTER_SIZE * 0.3, PI, TWO_PI);

    pop(); // Restaura o estado anterior da transformação
  }

  setDirection(dx, dy) {
    this.dirX = dx;
    this.dirY = dy;
  }

  collidesWith(crop) {
    let d = dist(this.x, this.y, crop.x, crop.y);
    // Ajuste a distância de colisão para a nova forma da colheitadeira,
    // focando mais na área da plataforma de corte.
    // Pode ser necessário ajustar o valor 0.7 para o jogo funcionar melhor
    return d < (HARVESTER_SIZE * 0.7 + CROP_SIZE * 0.4);
  }
}

class Crop {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.size = CROP_SIZE;
    this.growthStage = 0; // 0 = pequena, 1 = média, 2 = pronta para colher
    this.maxGrowthStage = 2;
    this.growthSpeed = random(0.005, 0.015); // Velocidade de crescimento
  }

  update() {
    if (this.growthStage < this.maxGrowthStage) {
      this.growthStage += this.growthSpeed;
      this.growthStage = min(this.growthStage, this.maxGrowthStage);
    }
  }

  display() {
    this.update(); // Atualiza o crescimento
    let currentSize = map(this.growthStage, 0, this.maxGrowthStage, CROP_SIZE * 0.5, CROP_SIZE);

    // Cor varia com o estágio de crescimento
    let currentGreen = map(this.growthStage, 0, this.maxGrowthStage, 100, COLOR_CROP[1]);
    fill(COLOR_CROP[0], currentGreen, COLOR_CROP[2]);

    ellipse(this.x, this.y, currentSize, currentSize * 1.2);
    rect(this.x - currentSize / 4, this.y + currentSize * 0.4, currentSize / 2, currentSize * 0.3);
  }
}

// Classe para as partículas (feedback visual da colheita)
class Particle {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.vx = random(-2, 2);
    this.vy = random(-5, -1);
    this.alpha = 255;
    this.size = random(5, 15);
  }

  update() {
    this.x += this.vx;
    this.y += this.vy;
    this.alpha -= 5; // Desaparece gradualmente
  }

  display() {
    noStroke();
    fill(COLOR_PARTICLE[0], COLOR_PARTICLE[1], COLOR_PARTICLE[2], this.alpha);
    ellipse(this.x, this.y, this.size);
  }

  isFinished() {
    return this.alpha < 0;
  }
}

// --- Funções da Interface do Usuário (UI) ---

function drawStartScreen() {
  background(0, 50, 100);
  fill(255);
  textSize(48);
  textAlign(CENTER, CENTER);
  text("Colheita no Campo", width / 2, height / 2 - 80);
  textSize(28);
  text("Use SETAS para Mover", width / 2, height / 2 + 0);
  text("W para Acelerar / S para Desacelerar", width / 2, height / 2 + 40);
  textSize(20);
  text("Gerencie a saúde e eficiência da sua máquina!", width / 2, height / 2 + 100);
  textSize(32);
  text("Pressione ENTER para Começar", width / 2, height / 2 + 160);
}

function displayUI() {
  fill(255); // Texto branco para contraste
  textSize(20);
  textAlign(LEFT, TOP);
  text("Pontos: " + floor(score), 10, 10);
  text("Nível: " + level, 10, 40);

  textAlign(RIGHT, TOP);

  // Barra de Saúde da Máquina
  let healthWidth = map(machineHealth, 0, MAX_HEALTH, 0, 150);
  let healthColor = lerpColor(color(255, 0, 0), color(0, 200, 0), machineHealth / MAX_HEALTH);

  fill(healthColor);
  rect(width - 160, 10, healthWidth, 20); // Barra de saúde
  noFill();
  stroke(255);
  rect(width - 160, 10, 150, 20); // Borda da barra
  noStroke();
  fill(255);
  text("Saúde: " + floor(machineHealth) + "%", width - 10, 10);


  // Eficiência
  let efficiencyColor = lerpColor(color(255, 150, 0), color(0, 150, 255), (harvestEfficiency - 0.5) / 1.5);
  fill(efficiencyColor);
  text("Eficiência: x" + harvestEfficiency.toFixed(1), width - 10, 40);
}

function checkGameEnd() {
  if (machineHealth <= 0) {
    fill(200, 0, 0); // Texto de game over vermelho
    textSize(60);
    textAlign(CENTER, CENTER);
    text("MÁQUINA QUEBROU!", width / 2, height / 2 - 40);
    textSize(35);
    text("Pontuação Final: " + floor(score), width / 2, height / 2 + 20);
    textSize(25);
    text("Pressione F5 para Reiniciar", width / 2, height / 2 + 70);
    noLoop();
  }
}